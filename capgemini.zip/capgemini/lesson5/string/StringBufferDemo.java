package com.capgemini.lesson5.string;

class StringBufferDemo {
   public static void main(String args[])  {

      // StringBuffer length vs. capacity.
      StringBuffer buffer = new StringBuffer("Hello");
      System.out.println("buffer = " + buffer);
      System.out.println("length = " + buffer.length());
      System.out.println("capacity = " + buffer.capacity());

      // appending and inserting into StringBuffer.
      String s;
      int a = 42;
      buffer = new StringBuffer(40);
      s = buffer.append("a = ").append(a).append("!").toString();
      System.out.println(s);

      String s1="Hello";
      StringBuffer sb1=new StringBuffer(s1);
      //covert StringBuffer object String object
      String s2=sb1.toString();
      
      buffer = new StringBuffer("I Java!");
      buffer.insert(2, "like ");
      System.out.println(buffer);
buffer.delete(0, 3);
System.out.println(buffer);
//lower-bound inclusive, upper-bound non-inclusive
String s3=buffer.substring(3,5);
System.out.println(s3);
System.out.println(s1.matches("11"));
System.out.println(s1.contains("11"));
   //matches() used along with regualr expression
String pattern="[a-zA-Z]*";
s1="";
System.out.println(s1.matches(pattern));
int empno=1234;
String pattern1="[0-9] {4}";
String string=new Integer(empno).toString();
System.out.println(string.matches(pattern1));
String pattern2="^[a-zA-z0-9._%]{4,10}$";
String password="abc_xyz?";
System.out.println(password.matches(pattern2));
   
   }
}
